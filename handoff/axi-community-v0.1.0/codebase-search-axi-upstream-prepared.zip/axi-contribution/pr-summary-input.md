# Proposed title

docs(catalog): add codebase-search-axi community proposal

# Factual input for the no-mistakes-generated PR body

Add one community entry for codebase-search-axi, a TypeScript/Node wrapper over ripgrep using axi-sdk-js. Regenerate README.md and docs/index.html with `pnpm run docs:gen`. The proposal changes only those three files.

Public candidate: [v0.1.0](https://github.com/pikos-apikos/codebase-search-axi/releases/tag/v0.1.0), source revision [`3dc5b60ff3adf58086ecdb6f1fd45d1c919fe102`](https://github.com/pikos-apikos/codebase-search-axi/tree/3dc5b60ff3adf58086ecdb6f1fd45d1c919fe102), MIT, Node >=20 and installed rg required. Default TOON and explicit JSON are supported. No reliable token savings or general agent-performance improvement is claimed.

[Contributor evidence in issue #10](https://github.com/pikos-apikos/codebase-search-axi/issues/10) identifies inspected entrypoint, cli/backend/results/policy/argv source and locked SDK distribution. It also records gaps: static no-args view, no session-end capture, incomplete contextual hints/help, wider default search schemas, and usage exit 1 in TOON versus exit 2 in JSON. Independent pinned-source review under VISION.md remains necessary. This proposal contains no admission verdict or exception approval.

Local upstream gates passed: docs generation/drift, docs tests 11/11, formatting, lint, SDK build and 185/185 SDK tests. Pinned tool package/skill checks passed. Its local public suite has 68 passing tests and one ptrace-dependent environmental failure; excluding that named test passes the other 68. Exact published-source hosted CI is green. These receipts do not replace the no-mistakes pipeline or candidate PR CI.

This file is input for the official workflow, not a manually submitted PR body. Let no-mistakes generate the real body/signature/head-bound attestation. Do not paste a signature or represent the local checks as a completed no-mistakes run.
