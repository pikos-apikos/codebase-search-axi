## Authorization update — 2026-10-13

External submission is authorized. The original preparation boundary below is historical. See issue #10 comment 6148121626 for authorization and the current execution-host blocker. Any new paid pipeline execution still requires separately recorded authorization and budget. The prepared commit and contribution bundle are unchanged. Local transient workspace prefixes in three logs were replaced with <local-workspace> for public handoff.

# Prepared contribution and authorization boundary

STATE: PREPARED. No fork branch was pushed and no upstream PR was opened.
GOAL: Submit the approved community proposal through upstream's official no-mistakes workflow.
SCOPE: catalog.yaml, README.md, docs/index.html in kunchenguid/axi; target main.
DECISION OWNER: HUMAN for external submission and new paid pipeline execution. Upstream maintains admission authority.

Prepared branch: community/codebase-search-axi-v0.1.0.
Prepared commit: afdd6c0bfed8f173fd577d352a9b958bc0852956.
Required upstream base: f979358f3dbda35009b14b1afad344ffde87ebba.
Pinned tool source: 3dc5b60ff3adf58086ecdb6f1fd45d1c919fe102 (v0.1.0).

## Restore for inspection (no submission)

Use an authenticated host only for subsequent submission. Reading/restoring the public source needs no paid pipeline.
Clone the parent repository. Keep origin pointed at the parent, as CONTRIBUTING requires. Replace /absolute/path/to/contribution.bundle with the extracted artifact path.

```sh
git clone https://github.com/kunchenguid/axi.git axi
cd axi
git fetch origin f979358f3dbda35009b14b1afad344ffde87ebba
git bundle verify /absolute/path/to/contribution.bundle
git fetch /absolute/path/to/contribution.bundle refs/heads/community/codebase-search-axi-v0.1.0:refs/heads/community/codebase-search-axi-v0.1.0
git switch community/codebase-search-axi-v0.1.0
git rev-parse HEAD
git diff f979358f3dbda35009b14b1afad344ffde87ebba..HEAD --stat
```

HEAD MUST equal the prepared commit. The bundle restores its exact commit metadata; contribution.patch is a readable fallback and applying it as a new commit may produce another SHA. Three full generated files are included under proposed/ for inspection. Check SHA256SUMS before relying on the artifact bytes.

## Human-gated submission

1. Obtain explicit authorization for the named prepared contribution and external no-mistakes submission. Obtain authorization for any new paid pipeline run. No spend budget is established by this preparation.
2. Recheck current upstream CONTRIBUTING.md, VISION.md, AXI principles and main before submission. If new requirements or material source changes invalidate this evidence, stop and revise the prepared result before requesting authorization again.
3. Create or identify an actual GitHub fork owned by pikos-apikos. The attempted read of pikos-apikos/axi returned 404 during preparation; do not treat that name as an existing fork. No fork-creation action is available through the currently exposed GitHub connector tools.
4. Use an authenticated host with gh, a supported pipeline agent, and no-mistakes installed. The observed latest release is v1.84.0; CONTRIBUTING specifies >=1.30.1 for forks, while current CI requires a modern head-bound pipeline attestation. Verify the installed runtime supports that gate. Do not install account-level integrations under the preparation-only authorization.
5. Keep origin as kunchenguid/axi and initialize the gate with the actual fork. For a fork actually named pikos-apikos/axi, the documented sequence is:

```sh
no-mistakes --version
no-mistakes init --fork-url git@github.com:pikos-apikos/axi.git
git push no-mistakes community/codebase-search-axi-v0.1.0
no-mistakes
```

6. The last two commands start the AI pipeline and, when gates pass, forward to the fork and open the upstream PR automatically. MUST NOT run them before authorization. MUST NOT replace this route with a direct push or connector-created PR. MUST NOT hand-write the no-mistakes signature/attestation.
7. Use pr-summary-input.md and the #10 evidence as factual context for the workflow's generated PR. Preserve pinned source identity, limitations and the independent admission gate. Stop if findings require expanded scope or a human-owned choice. Do not silently convert a materially revised candidate into the already approved revision.
8. Verify the actual resulting PR head, head-bound attestation and all triggered upstream checks. Record its URL, final commit and pipeline/CI receipts on #10. Reconcile #1. Do not claim that submission or green automation establishes independent admission.

DONE WHEN: The authorized PR was submitted through the real workflow, its actual revision and outcome are recorded, and the map reflects the maintainer-owned review stage. Until then keep #10 open.
