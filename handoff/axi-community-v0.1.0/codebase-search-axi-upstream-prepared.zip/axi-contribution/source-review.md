# codebase-search-axi: contributor preparation evidence

Status: **PREPARED; NOT SUBMITTED; ADMISSION INCONCLUSIVE**.
This is contributor evidence. It is not the independent admission verdict required by upstream VISION.md.

## Revisions and scope

- Published package: [v0.1.0 pre-release](https://github.com/pikos-apikos/codebase-search-axi/releases/tag/v0.1.0).
- Inspected tool source: [`3dc5b60ff3adf58086ecdb6f1fd45d1c919fe102`](https://github.com/pikos-apikos/codebase-search-axi/tree/3dc5b60ff3adf58086ecdb6f1fd45d1c919fe102).
- Release API identifies that commit and reports tarball SHA-256 `9b149f5ac67d79fd7bd98c5539ac6f175803d7421bcdfd2ecf9fd1af05b06d38`. This preparation inspected the pinned source checkout; it did not download and independently hash the released asset.
- Upstream base: [`f979358f3dbda35009b14b1afad344ffde87ebba`](https://github.com/kunchenguid/axi/tree/f979358f3dbda35009b14b1afad344ffde87ebba).
- Local contribution branch: `community/codebase-search-axi-v0.1.0`.
- Contribution commit: `afdd6c0bfed8f173fd577d352a9b958bc0852956`.
- Contribution tree: `3a749278bc5c823eaaec2fdff563dbe00f6d131d`.
- Only `catalog.yaml`, `README.md`, and `docs/index.html` change: 22 insertions, no deletions. No edits to the official catalog, AXI principles, SDK, release metadata or published tool.
- PR #25 publication documentation is already merged; no attempt was made to repeat it. The source review applies to the release commit, including its historical documentation, not to later main.

## Upstream requirements inspected

At the upstream base, read `AGENTS.md`, `CONTRIBUTING.md`, `VISION.md`, `principles.yaml`, `.agents/skills/axi/SKILL.md`, `scripts/generate-docs.mjs`, and the four relevant workflows: `docs-check.yml`, `axi-sdk-js-ci.yml`, `guard-generated-files.yml`, and `no-mistakes-required.yml`.

CONTRIBUTING requires one `community` entry and regeneration of both rendered files with `pnpm run docs:gen`. It requires Node 24 and the documented pnpm gates. Fork contributions must use no-mistakes >=1.30.1, with `origin` pointing to the parent and the fork configured by `no-mistakes init --fork-url`.

The current PR gate is stronger than a signature-only check. It calls the shared no-mistakes action at `f6441c96c352a18b9cadcaef6b6c7017e9ac3970` (v1.80.1). The inspected action requires a pipeline-step attestation bound to the actual PR head, with review, test and document completed. A manually inserted signature or copied attestation does not satisfy the intended workflow. The latest release observed during preparation is no-mistakes v1.84.0. The runtime is not installed here, and no init or paid pipeline was started.

VISION reserves admission for an independent reviewer who inspects actual package source at a pinned revision. Contributor assertions, generated docs and test receipts do not establish admission. The proposed entry has no `admission` field, no approved status and no exception verdict.

The readable active `main` ruleset requires a PR, linear history, and squash merging; it exposes no required-status-check rule. Legacy branch-protection GET returned HTTP 403 (`Resource not accessible by integration`), so its additional requirements remain unverified. Workflow-defined checks are documented below regardless of that access gap.

## Principle-to-source checklist

Links below resolve into the inspected release revision. Dependency observations are based on the installed `axi-sdk-js@0.1.13` distribution from the committed lockfile, not an assumption that today's SDK main matches it.

| AXI principle | Direct source observations | Remaining gap / conclusion |
| --- | --- | --- |
| 1. Token-efficient output | [`src/cli.ts`](https://github.com/pikos-apikos/codebase-search-axi/blob/3dc5b60ff3adf58086ecdb6f1fd45d1c919fe102/src/cli.ts): handlers return objects for default SDK TOON rendering; explicit `--json` or `--format json` returns a serialized JSON envelope. Internal results remain objects. SDK `dist/output.js` calls the TOON encoder at the output boundary. | Representation is supported. No reliable token-saving or general agent-performance claim is established by the curated evaluation. |
| 2. Minimal default schemas | [`src/results.ts`](https://github.com/pikos-apikos/codebase-search-axi/blob/3dc5b60ff3adf58086ecdb6f1fd45d1c919fe102/src/results.ts): files are scalar paths; count rows have path/count. `src/cli.ts` validates and projects `--fields`. Default result limit is 50. | Search rows contain path, line, column, text, submatches and text_bytes; context adds before/after and optional span metadata. Those defaults exceed the principle's usual 3-4 fields and duplicate matched text. Minimality and representative adequacy of limit 50 are not established. |
| 3. Content truncation | `src/cli.ts` `applyTextBound` records `text_bytes` and `text_truncated`; `applyOutputBound` updates returned/count and `complete.display`. `--full` disables display/scan bounds and optional exclusions while retaining mandatory denies. | Row-limit truncation produces a hint, but text-byte and serialized-byte truncation introduced after `envelope()` can set display=false without a recovery hint. Text byte metadata covers exposed text/submatch payload, not the original file length. Full principle compliance is not established. |
| 4. Pre-computed aggregates | `src/results.ts` `envelope`, `files`, `matches`, `count`, `metrics`: shown counts, exact totals after complete scans, per-file and aggregate matching-line/occurrence counts, matched_files and bounded metrics observations. Incomplete scans omit exact totals. | Aggregation and honest total/observation distinction are supported by representative code paths. No expensive derived repository-state aggregation is claimed. |
| 5. Definitive empty states | `src/results.ts` emits status=ok, empty arrays, zero counts and completeness; complete empty scans report total=0. Backend treats rg's no-match exit 1 as successful when the stream reports completion. | Supported structured empty states. A zero from an incomplete scan has scan=false and omits total; it must not be read as definitive absence. |
| 6. Structured errors and exit codes | [`src/backend.ts`](https://github.com/pikos-apikos/codebase-search-axi/blob/3dc5b60ff3adf58086ecdb6f1fd45d1c919fe102/src/backend.ts) maps failures into `RgError`/`AxiError`, uses ignored stdin, and keeps backend diagnostics on stderr. `src/cli.ts` validates before root/rg dispatch, rejects unknown arguments and emits structured stdout errors. | Concrete mismatch: unknown flag or missing pattern yields exit 1 in default TOON because tool usage codes differ from the SDK's `VALIDATION_ERROR` mapping; JSON returns exit 2. Unknown-flag errors lack an inline valid-flag list; JSON errors discard suggestions. Raw backend stderr is forwarded as diagnostics and is outside structured stdout. The SDK's built-in `update` is also reachable; this report did not execute its registry/install path. Search commands are read-only; the whole CLI is not claimed to have no write-capable commands. |
| 7. Ambient context | `src/cli.ts` `setupCommand` calls SDK hook install/status/uninstall only after explicit setup, and requires an isolated `--home`. Installed SDK `dist/hooks.js` has portable/path-repair and idempotent managed SessionStart entries for Claude/Codex, an OpenCode plugin, and Codex hooks-feature configuration. Ordinary searches do not install hooks. | Personal-home and project installs are deliberately rejected. Hooks invoke the static home view, not live directory state. No session-end capture exists. [`scripts/check-skill.mjs`](https://github.com/pikos-apikos/codebase-search-axi/blob/3dc5b60ff3adf58086ecdb6f1fd45d1c919fe102/scripts/check-skill.mjs) only compares two static skill copies; it does not generate skill content from home. Skill examples require a prior local package installation. Full lifecycle/discovery compliance is not established. |
| 8. Content first | `src/cli.ts` `main` defines home as static orientation, command names and hints; installed SDK `dist/cli.js`/`dist/output.js` prepends bin and description. | Confirmed gap: no live codebase content or directory-relevant state is read by the no-args handler. The existing test explicitly expects orientation without scanning. |
| 9. Contextual disclosure | `src/results.ts` emits hints for row-limited results, incomplete count scans and bounded metrics. Home supplies two discovery hints. | Complete files/search lists and empty lists have no next-step suggestions. Truncation hints are flag fragments rather than complete commands retaining pattern/root/policy/filters. Incomplete files/search scans can have no hint. Error suggestions are generic or absent in JSON. Full principle compliance is not established. |
| 10. Consistent help | [`bin/codebase-search`](https://github.com/pikos-apikos/codebase-search-axi/blob/3dc5b60ff3adf58086ecdb6f1fd45d1c919fe102/bin/codebase-search) uses SDK `fast-path` with import-free [`src/version.ts`](https://github.com/pikos-apikos/codebase-search-axi/blob/3dc5b60ff3adf58086ecdb6f1fd45d1c919fe102/src/version.ts) before dynamic CLI import. `src/cli.ts` `commandHelp` supplies per-command help. SDK header identifies bin/description. | Bare -v/-V/--version return 0.1.0 and exit 0. Tool command help lacks 2-3 examples and omits supported --hidden/--no-ignore and some defaults; setup help omits --json and isolated-home restriction. No version-latency measurement was made. |

Additional inspected paths: `src/policy.ts` (explicit TOML configuration, positive-safe integer bounds, mandatory and optional globs, root canonicalization), `src/argv.ts` (Linux raw argv fallback and UTF-8 checks), `test/cli-contract.test.mjs`, `test/rg-fidelity.test.mjs`, `tests/codebase-search.test.sh`, `scripts/package-check.mjs`, `skills/codebase-search/SKILL.md`, `package.json`, `package-lock.json`, `.github/workflows/ci.yml`, and `docs/evaluation.md`.

The mandatory exclusion claim is supported by the backend appending mandatory deny globs after caller filters, plus denied-root checks in policy. This is a policy of this tool's commands, not an OS sandbox or a general secret-detection guarantee. Source inspection does not independently verify every ripgrep or agent-harness behavior. The probes and existing test suite are supporting observations, not admission authority.

## Validation

Environment: Node v24.19.0, pnpm v11.1.1 (matching upstream packageManager). No new benchmarks or paid agent runs.

| Command / gate | Result |
| --- | --- |
| pnpm install --frozen-lockfile | PASS; root/workspace lockfile preserved |
| pnpm run docs:gen | PASS; only expected community row generated |
| pnpm run docs:test | PASS: 11/11 |
| pnpm run docs:check | PASS |
| pnpm run format:check | PASS |
| pnpm run lint | PASS |
| pnpm --dir packages/axi-sdk-js run build | PASS |
| pnpm --dir packages/axi-sdk-js test | PASS: 185/185 in 6 files |
| git diff --check HEAD^ HEAD | PASS |
| Regeneration after commit + git diff --exit-code | PASS: idempotent; clean checkout |
| Guard generated files | Changed-path inspection PASS: neither release-please generated file is modified; remote PR job not run |
| Require no-mistakes | NOT RUN: no authorized submission/pipeline, no signature or attestation fabricated |
| npm ci (pinned published source) | PASS |
| bash -n tests/codebase-search.test.sh | PASS |
| bash tests/codebase-search.test.sh | 68 PASS, 1 FAIL: strace cannot PTRACE_TRACEME in this environment (Operation not permitted) |
| node --test --test-skip-pattern='^scan byte bounds avoid content reads and files discovery survives EACCES$' | PASS: 68 selected tests; the same one test deliberately omitted, not repaired or claimed passing |
| npm run check:skill | PASS: the two checked-in skill copies match |
| npm run package:check | PASS: clean package installation/search and isolated integration lifecycle |
| Source probes | 17 observations recorded in logs/source-probes.json; confirms mode-dependent usage exit codes and missing truncation hints |
| git bundle verify | PASS; bundle requires the pinned upstream base |

All upstream local checks ran on the exact file contents committed as contribution tree `3a749278bc5c823eaaec2fdff563dbe00f6d131d`; the post-commit regeneration verified no drift. The catalog-only change does not trigger SDK CI by its path filter, but its documented local gates were still run. Hosted PR checks do not exist for this local candidate.

Observed hosted receipts: release source CI [37928439182](https://github.com/pikos-apikos/codebase-search-axi/actions/runs/37928439182) is successful at the exact published commit, with CLI suite, skill and package steps successful. Upstream baseline docs-check [38152085525](https://github.com/kunchenguid/axi/actions/runs/38152085525) is successful at the upstream base. Neither receipt is a hosted CI result for the proposed catalog commit.

## Disposition

Prepare the neutral community proposal and disclose these gaps. Do not recommend independent admission, invent an exception approval or claim all principles pass. Upstream maintainers may request changes or independently decide an exception; no such decision is recorded here. The separate authorization must cover the concrete external submission and any new paid no-mistakes pipeline run. Issue #10 remains open, and no successor is promoted.
